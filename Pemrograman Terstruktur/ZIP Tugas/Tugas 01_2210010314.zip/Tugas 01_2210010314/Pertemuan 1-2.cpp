/*
program pertemuan 1-2
contoh proses pindah baris
pindah baris dapat dilakukan dengan \n atau <<endl; 
*/
#include <iostream> // memanggil atau menginclude semua fungsi yang ada di iostream
using namespace std;

int main (){ //fungsi utama 
	cout<<"\nSelamat Datang di Bahasa C++";
	cout<<endl<<"Bahasa C++ sangat mudah untuk dipahami"<<endl;
	cout<<"Mari Belajar Bersama "<<endl;
}
