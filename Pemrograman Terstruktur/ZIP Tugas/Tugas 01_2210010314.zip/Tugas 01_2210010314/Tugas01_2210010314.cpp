#include <iostream> // memanggil iostream
using namespace std;

int main (){// fungsi utama
	cout<<"-------TUGAS PERTAMA-----------------------------"<<endl;
	cout<<"-------------------------------------------------"<<endl;
	cout<<"Nama\t\t : Muhammad Adam Alghifari"<<endl;
	cout<<"NPM\t\t : 2210010314"<<endl;
	cout<<"Semester\t : III\n";
	cout<<"Mata Kuliah\t : P. Terstruktur\n";
	cout<<"Kelas\t\t : 3B BJB Pagi\n";
	cout<<"-------------------------------------------------"<<endl;
	cout<<"---------Terima Kasih----------------------------"<<endl;
}
/*
 fungsi /t : untuk Tab
 fungsi /n : untuk new line sama dengan <<endl; (end line)
*/
