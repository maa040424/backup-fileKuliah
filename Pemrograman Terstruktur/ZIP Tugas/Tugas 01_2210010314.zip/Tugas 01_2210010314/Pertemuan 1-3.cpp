/*
Nama : Muhammad Adam Alghifari
Npm  : 2210010314
program Pertemuan 1-3
contoh proses penggunaan tab
penggunaan tab dapat menggunakan \t
*/

#include <iostream> // memanggil header utama iostream
using namespace std;

int main () {
	cout<<"\nSelamat Datang Di Bahasa C++";
	cout<<"\t\t Mari Belajar Bersama "<<endl;
}

		