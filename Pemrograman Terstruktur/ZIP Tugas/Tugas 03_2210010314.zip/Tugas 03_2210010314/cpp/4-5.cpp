#include <iostream>
using namespace std;
int main() {
	
cout<< "+==============================+"<<endl;
cout<< "|Nama : Muhammad Adam Alghifari|"<<endl;
cout<< "|Npm  : 2210010314             |"<<endl;
cout<< "+==============================+"<<endl;
	
    int a = 5;

    cout << "Post dan Pre Increment" << endl;

    cout << "Isi variabel a: " << a << endl;

    cout << "Isi variabel a: " << a++ << endl;

    cout << "Isi variabel a: " << a << endl;

    cout << "Isi variabel a: " << ++a << endl;

    cout << "Isi variabel a: " << a << endl;

    cout << endl;

    int b = 5;

    cout << "Post dan Pre Decrement" << endl;

    cout << "Isi variabel b: " << b << endl;
    cout << "Isi variabel b: " << b-- << endl;
    cout << "Isi variabel b: " << b << endl;
    cout << "Isi variabel b: " << --b << endl;
    cout << "Isi variabel b: " << b << endl;

    return 0;
}