#include <iostream>
using namespace std;

int main() {

    cout << "+==============================+" << endl;
    cout << "|Nama : Muhammad Adam Alghifari|" << endl;
    cout << "|Npm  : 2210010314             |" << endl;
    cout << "+==============================+" << endl;

    int a, b, c, d, e, f;

    a = 8 + 4;
    b = 9 - 2;
    c = 2 * 3;
    d = 10 + 3 - 7 * 4;
    e = ((10 + 3) - 7) * 4; 
    f = -79;

    cout << " Isi Variabel a:" << a << endl;
    cout << " Isi Variabel b:" << b << endl;
    cout << " Isi Variabel c:" << c << endl;
    cout << " Isi Variabel d:" << d << endl;
    cout << " Isi Variabel e:" << e << endl;
    cout << " Isi Variabel f:" << f << endl;

    return 0;
}
