#include <iostream>

using namespace std;

int main()

{
cout<< "+==============================+"<<endl;
cout<< "|Nama : Muhammad Adam Alghifari|"<<endl;
cout<< "|Npm  : 2210010314             |"<<endl;
cout<< "+==============================+"<<endl;	

int a, b, c, d;

a = 8 % 4;
b = 8% 5; 
c  = 10 % 2; 
d = 100 % 7;

cout << "Isi variabel a: " << a << endl;

cout << "Isi variabel b:" << b << endl; 

cout << "Isi variabel c:" << c << endl; 

cout<<"Isi variabel d: " << d << endl;
};
