#include <iostream>
using namespace std;

int main() {
	
cout<< "+==============================+"<<endl;
cout<< "|Nama : Muhammad Adam Alghifari|"<<endl;
cout<< "|Npm  : 2210010314             |"<<endl;
cout<< "+==============================+"<<endl;
	
	
	
    int a = 7;

    a++;

    cout << "Isi variabel a: " << a << endl;

    int b = 7;

    ++b;

    cout << "Isi variabel b: " << b << endl;

    int c = 7;

    cout << "Isi variabel c: " << c << endl;

    int d = 7;

    --d;

    cout << "Isi variabel d: " << d << endl;

    return 0;
}