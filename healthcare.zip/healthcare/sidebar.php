<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item nav-category">Menu</li>
    <li class="nav-item">
      <a class="nav-link" href="index.php">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title">Welcome</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="homecare.php">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title">Home Care</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="ambulan.php">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title">Ambulan</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="jadwal.php">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title">Jadwal Praktek</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="pengaduan.php">
        <span class="icon-bg"><i class="mdi mdi-cube menu-icon"></i></span>
        <span class="menu-title">Pengaduan</span>
      </a>
    </li>

  </ul>
</nav>